
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { ArrowRight, Code, Palette, Lightbulb } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <div className="pt-24 pb-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">About Hemanth</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Creator, thinker, and digital craftsman passionate about minimalist design and innovative solutions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <div className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <div className="aspect-square rounded-2xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600&h=600&fit=crop&crop=face" 
                  alt="Hemanth"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Hello, I'm Hemanth</h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Welcome to my digital space where I share thoughts, experiences, and creative explorations. 
                I believe in the power of simplicity and the beauty of well-crafted design.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Through this platform, I aim to inspire others while documenting my own journey of 
                continuous learning and growth in the ever-evolving world of technology and design.
              </p>
              <div className="flex space-x-4">
                <button className="bg-blue-600 text-white px-6 py-3 rounded-full hover:bg-blue-700 transition-all duration-300 flex items-center space-x-2">
                  <span>Get in Touch</span>
                  <ArrowRight size={20} />
                </button>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-20">
            {[
              {
                icon: Code,
                title: "Development",
                description: "Crafting clean, efficient code with modern technologies and best practices."
              },
              {
                icon: Palette,
                title: "Design",
                description: "Creating beautiful, user-centered experiences with attention to detail."
              },
              {
                icon: Lightbulb,
                title: "Innovation",
                description: "Exploring new ideas and pushing the boundaries of what's possible."
              }
            ].map((item, index) => (
              <div 
                key={item.title}
                className="text-center p-8 rounded-2xl bg-gray-50 hover:bg-gray-100 transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${0.6 + index * 0.2}s` }}
              >
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <item.icon size={32} className="text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>

          <div className="text-center bg-gradient-to-r from-blue-50 to-gray-50 rounded-2xl p-12 animate-fade-in" style={{ animationDelay: "1.2s" }}>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Let's Connect</h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Interested in collaborating or just want to say hello? I'd love to hear from you.
            </p>
            <button className="bg-gray-900 text-white px-8 py-4 rounded-full hover:bg-gray-800 transition-all duration-300 hover:scale-105 transform">
              Start a Conversation
            </button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default About;
