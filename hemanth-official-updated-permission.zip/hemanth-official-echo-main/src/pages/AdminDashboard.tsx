import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

interface Post {
  id: number;
  title: string;
  content: string;
  image?: string;
  youtubeLink?: string;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<Post[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [youtubeLink, setYoutubeLink] = useState("");
  const [permissionGranted, setPermissionGranted] = useState<boolean | null>(null);

  useEffect(() => {
    const isAdmin = localStorage.getItem("isAdmin");
    if (!isAdmin) navigate("/admin-login");
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("isAdmin");
    navigate("/");
  };

  const handleAddPost = () => {
    const newPost: Post = {
      id: Date.now(),
      title,
      content,
      youtubeLink,
    };

    if (image) {
      const reader = new FileReader();
      reader.onloadend = () => {
        newPost.image = reader.result as string;
        setPosts([newPost, ...posts]);
      };
      reader.readAsDataURL(image);
    } else {
      setPosts([newPost, ...posts]);
    }

    setTitle("");
    setContent("");
    setImage(null);
    setYoutubeLink("");
  };

  const handleDeletePost = (id: number) => {
    setPosts(posts.filter((post) => post.id !== id));
  };

  if (permissionGranted === null) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gray-100 text-center">
        <h1 className="text-xl font-bold mb-4">Storage Permission Required</h1>
        <p className="mb-6">This app needs access to your device storage to upload posts.</p>
        <div className="space-x-4">
          <button
            onClick={() => setPermissionGranted(true)}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            Allow
          </button>
          <button
            onClick={() => setPermissionGranted(false)}
            className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
          >
            Deny
          </button>
        </div>
      </div>
    );
  }

  if (!permissionGranted) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gray-100 text-center">
        <h1 className="text-xl font-bold mb-4 text-red-600">Permission Denied</h1>
        <p>You denied access to device storage. Reload the page to try again.</p>
      </div>
    );
  }

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-4">Admin Dashboard</h1>
      <button
        onClick={handleLogout}
        className="mb-6 bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
      >
        Logout
      </button>

      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Create New Post</h2>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="block mb-2 w-full border rounded px-3 py-2"
        />
        <textarea
          placeholder="Small thought or content..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="block mb-2 w-full border rounded px-3 py-2"
        />
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setImage(e.target.files?.[0] || null)}
          className="block mb-2"
        />
        <input
          type="text"
          placeholder="YouTube video link (optional)"
          value={youtubeLink}
          onChange={(e) => setYoutubeLink(e.target.value)}
          className="block mb-2 w-full border rounded px-3 py-2"
        />
        <button
          onClick={handleAddPost}
          className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
        >
          Post
        </button>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Your Posts</h2>
        {posts.map((post) => (
          <div key={post.id} className="border rounded p-4 mb-4 bg-white">
            <h3 className="text-lg font-bold">{post.title}</h3>
            <p>{post.content}</p>
            {post.image && (
              <img
                src={post.image}
                alt="Uploaded"
                className="mt-2 max-w-sm rounded"
              />
            )}
            {post.youtubeLink && (
              <div className="mt-2">
                <iframe
                  width="360"
                  height="215"
                  src={post.youtubeLink.replace("watch?v=", "embed/")}
                  frameBorder="0"
                  allowFullScreen
                  title="YouTube Video"
                ></iframe>
              </div>
            )}
            <button
              onClick={() => handleDeletePost(post.id)}
              className="mt-4 bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded"
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;