
import Hero from "@/components/Hero";
import FeaturedPosts from "@/components/FeaturedPosts";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <Hero />
      <FeaturedPosts />
      <Footer />
    </div>
  );
};

export default Index;
