
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import PostCard from "@/components/PostCard";
import { useState } from "react";
import { Filter } from "lucide-react";

const Posts = () => {
  const [filter, setFilter] = useState("all");

  const posts = [
    {
      id: 1,
      title: "The Art of Minimalism",
      excerpt: "Exploring how less can truly be more in our digital age. This comprehensive guide walks through the principles of minimalist design and how they apply to both digital and physical spaces.",
      thought: "Sometimes the most powerful statements are made in silence.",
      date: "Dec 15, 2024",
      type: "text",
      image: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&h=600&fit=crop"
    },
    {
      id: 2,
      title: "Innovation in Design",
      excerpt: "A journey through modern design principles and their impact on user experience. We'll explore how innovative thinking shapes the digital products we use every day.",
      thought: "Design is not just what it looks like - design is how it works.",
      date: "Dec 12, 2024",
      type: "video",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop"
    },
    {
      id: 3,
      title: "Future Perspectives",
      excerpt: "Looking ahead at the technologies shaping tomorrow. From AI to sustainable design, we examine the trends that will define the next decade.",
      thought: "The future belongs to those who prepare for it today.",
      date: "Dec 10, 2024",
      type: "image",
      image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&h=600&fit=crop"
    },
    {
      id: 4,
      title: "Creative Process",
      excerpt: "Behind the scenes of creative work and the methodologies that drive innovation. Understanding the iterative nature of great design.",
      thought: "Creativity is intelligence having fun.",
      date: "Dec 8, 2024",
      type: "text",
      image: "https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=800&h=600&fit=crop"
    }
  ];

  const filteredPosts = filter === "all" ? posts : posts.filter(post => post.type === filter);

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <div className="pt-24 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">All Posts</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Explore all thoughts, stories, and creative expressions
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
            <div className="flex items-center space-x-2 text-gray-600">
              <Filter size={20} />
              <span className="font-medium">Filter:</span>
            </div>
            {["all", "text", "video", "image"].map((type) => (
              <button
                key={type}
                onClick={() => setFilter(type)}
                className={`px-6 py-2 rounded-full font-medium transition-all ${
                  filter === type
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, index) => (
              <PostCard key={post.id} post={post} delay={index * 0.1} />
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Posts;
