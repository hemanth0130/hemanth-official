
import { Calendar, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const FeaturedPosts = () => {
  const featuredPosts = [
    {
      id: 1,
      title: "The Art of Minimalism",
      excerpt: "Exploring how less can truly be more in our digital age...",
      thought: "Sometimes the most powerful statements are made in silence.",
      date: "Dec 15, 2024",
      type: "text",
      image: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&h=600&fit=crop"
    },
    {
      id: 2,
      title: "Innovation in Design",
      excerpt: "A journey through modern design principles and their impact...",
      thought: "Design is not just what it looks like - design is how it works.",
      date: "Dec 12, 2024",
      type: "video",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop"
    },
    {
      id: 3,
      title: "Future Perspectives",
      excerpt: "Looking ahead at the technologies shaping tomorrow...",
      thought: "The future belongs to those who prepare for it today.",
      date: "Dec 10, 2024",
      type: "image",
      image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&h=600&fit=crop"
    }
  ];

  return (
    <section className="py-20 px-6 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Featured Posts</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover the latest thoughts, insights, and creative expressions
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredPosts.map((post, index) => (
            <div 
              key={post.id} 
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 group animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="aspect-video overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <Calendar size={16} className="mr-2" />
                  <span>{post.date}</span>
                  <span className="ml-3 px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-medium">
                    {post.type}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                  {post.title}
                </h3>
                <p className="text-gray-600 mb-4 line-clamp-2">
                  {post.excerpt}
                </p>
                <div className="border-t border-gray-100 pt-4">
                  <p className="text-sm italic text-gray-500 mb-3">"{post.thought}"</p>
                  <button className="text-blue-600 font-medium flex items-center space-x-1 hover:space-x-2 transition-all">
                    <span>Read More</span>
                    <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link 
            to="/posts" 
            className="inline-flex items-center space-x-2 bg-gray-900 text-white px-8 py-4 rounded-full hover:bg-gray-800 transition-all duration-300 hover:scale-105 transform"
          >
            <span className="font-medium">View All Posts</span>
            <ArrowRight size={20} />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedPosts;
