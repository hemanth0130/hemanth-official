
import { Calendar, ArrowRight } from "lucide-react";

interface Post {
  id: number;
  title: string;
  excerpt: string;
  thought: string;
  date: string;
  type: string;
  image: string;
}

interface PostCardProps {
  post: Post;
  delay?: number;
}

const PostCard = ({ post, delay = 0 }: PostCardProps) => {
  return (
    <div 
      className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 group animate-fade-in"
      style={{ animationDelay: `${delay}s` }}
    >
      <div className="aspect-video overflow-hidden">
        <img 
          src={post.image} 
          alt={post.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
      </div>
      <div className="p-6">
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <Calendar size={16} className="mr-2" />
          <span>{post.date}</span>
          <span className="ml-3 px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-medium">
            {post.type}
          </span>
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
          {post.title}
        </h3>
        <p className="text-gray-600 mb-4 line-clamp-3">
          {post.excerpt}
        </p>
        <div className="border-t border-gray-100 pt-4">
          <p className="text-sm italic text-gray-500 mb-3">"{post.thought}"</p>
          <button className="text-blue-600 font-medium flex items-center space-x-1 hover:space-x-2 transition-all">
            <span>Read More</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default PostCard;
